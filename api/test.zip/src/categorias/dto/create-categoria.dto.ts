export class CreateCategoriaDto {}
