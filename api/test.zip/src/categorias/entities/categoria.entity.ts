export class Categoria {}
