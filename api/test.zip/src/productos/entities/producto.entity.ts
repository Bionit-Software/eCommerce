export class Producto {
  id: number;
  nombre: string;
  descripcion: string;
  url_image: string;
  precio: number;
  stock: number;
  idCategoria: number;
  idMarca: number;
  createdAt: Date;
  updatedAt: Date;
}
