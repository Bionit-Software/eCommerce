export class Pagina {}
