export class CreatePaginaDto {}
