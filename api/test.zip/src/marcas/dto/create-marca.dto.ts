export class CreateMarcaDto {}
